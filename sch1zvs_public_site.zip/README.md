# sch1zvs_public

Strona z configami NeverLose i linkiem do Discorda, w neonowym stylu.

## Jak to wystawić na GitHub Pages

1. Wrzuć zawartość tego folderu (`index.html`, `style.css`, `script.js`, folder `configs/`) do głównego katalogu repo `Sch1zVs/sch1zvs_public` (branch `main`).
2. W repo wejdź w **Settings → Pages**.
3. Przy **Source** wybierz branch `main` i folder `/root`, zapisz.
4. Po chwili strona będzie dostępna pod `https://sch1zvs.github.io/sch1zvs_public/`.

## Jak podmienić link do Discorda

W plikach `index.html` znajdź `https://discord.gg/TWOJ-INVITE` (występuje 3 razy) i zamień na swój link zaproszenia.

## Jak dodać nowy config

1. Wrzuć plik `.cfg` do folderu `configs/`.
2. Otwórz `script.js` i dodaj nowy wpis do tablicy `CONFIGS`, np.:

```js
{
  name: "Nazwa configu",
  tag: "krotki-tag",
  desc: "Opis w jednym zdaniu — do czego się nadaje.",
  file: "configs/nazwa-pliku.cfg"
}
```

Karta na stronie i link do pobrania pojawią się automatycznie.

## Struktura

```
.
├── index.html
├── style.css
├── script.js
└── configs/
    ├── legit.cfg
    ├── semi-legit.cfg
    ├── visuals.cfg
    └── rage.cfg
```
